import streamlit as st
from descriptor import glcm, bitdesc
from distances import euclidean, manhattan, chebyshev, canberra
import numpy as np
import os
import requests
from PIL import Image


def download_image(url, filename):
    with open(filename, 'wb') as f:
        response = requests.get(url)
        f.write(response.content)


def calculate_distances(query_features, signature_db, distance_func):
    distances = []
    for instance in signature_db:
        signature_features = instance[:-2]
        label = instance[-2]
        img_path = instance[-1]
        dist = distance_func(query_features, signature_features)
        distances.append((img_path, dist, label))
    distances.sort(key=lambda x: x[1])
    return distances


def main():
    st.title('Image Retrieval System')


    st.sidebar.header('Upload Image')
    image_url = st.sidebar.text_input('Enter Image URL:')
    descriptor_type = st.sidebar.selectbox('Choose Descriptor', ['GLCM', 'Bitdesc'])
    distance_method = st.sidebar.selectbox('Choose Distance Method', ['Euclidean', 'Manhattan', 'Chebyshev', 'Canberra'])
    num_results = st.sidebar.slider('Number of Similar Images to Display', 1, 20, 5)

    if st.sidebar.button('Retrieve Similar Images'):

            temp_image_path = 'temp_image.png'
            download_image(image_url, temp_image_path)

            if descriptor_type == 'GLCM':
                query_features = glcm(temp_image_path)
            elif descriptor_type == 'Bitdesc':
                query_features = bitdesc(temp_image_path)

            signatures = np.load('signatures.npy', allow_pickle=True)

            if distance_method == 'Euclidean':
                distance_func = euclidean
            elif distance_method == 'Manhattan':
                distance_func = manhattan
            elif distance_method == 'Chebyshev':
                distance_func = chebyshev
            elif distance_method == 'Canberra':
                distance_func = canberra
            else:
                st.error('Unsupported distance method.')

            distances = calculate_distances(query_features, signatures, distance_func)

            st.header('Query Image')
            st.image(temp_image_path, caption='Query Image', use_column_width=True)

            st.header('Similar Images')
            for i in range(min(num_results, len(distances))):
                image_path = distances[i][0]
                dist_value = distances[i][1]
                label = distances[i][2]
                st.subheader(f'Distance: {dist_value:.2f}, Label: {label}')
                st.image(image_path, caption=f'Distance: {dist_value:.2f}', use_column_width=True)


if __name__ == '__main__':
    main()
